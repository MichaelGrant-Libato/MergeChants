import React from "react";
import "./style.css";


export default function Sell() {
  return (
    
      <div className="mc-page-container">
        <h1 className="mc-title">Sell an Item</h1>
        <p className="mc-description">Form to post a new listing will go here.</p>
      </div>
    
  );
}
 